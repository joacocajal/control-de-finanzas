// Shared building blocks for the Ascend dashboard.
// Components are exported to window so other Babel scripts can use them.

const { useState, useEffect, useRef, useMemo } = React;

// ---------- Icon ----------
function Icon({ name, size = 18, strokeWidth = 1.75, className = '', style }) {
  return (
    <i
      data-lucide={name}
      style={{ width: size, height: size, ...(style || {}) }}
      className={`inline-block shrink-0 ${className}`}
      data-stroke-width={strokeWidth}
    />
  );
}

// ---------- Glass card ----------
function Card({ children, className = '', as: Tag = 'div', accent, ...rest }) {
  return (
    <Tag className={`glass lift ${className}`} {...rest}>
      {children}
    </Tag>
  );
}

// ---------- Section header ----------
function SectionHeader({ kicker, title, icon, accent, right }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <div className="flex items-center gap-2.5">
        {icon ? (
          <div
            className="w-7 h-7 rounded-lg flex items-center justify-center"
            style={{ background: `${accent}1f`, color: accent }}
          >
            <Icon name={icon} size={15} />
          </div>
        ) : null}
        <div>
          {kicker ? (
            <div className="text-[10px] uppercase tracking-[0.18em] num" style={{ color: 'var(--text-2)' }}>
              {kicker}
            </div>
          ) : null}
          <div className="text-[15px] font-semibold display" style={{ color: 'var(--text-0)' }}>{title}</div>
        </div>
      </div>
      {right}
    </div>
  );
}

// ---------- Animated number ----------
function useAnimatedNumber(target, duration = 800) {
  const [val, setVal] = useState(target);
  const fromRef = useRef(target);
  useEffect(() => {
    const from = fromRef.current;
    const start = performance.now();
    let raf;
    const step = (t) => {
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(from + (target - from) * eased);
      if (p < 1) raf = requestAnimationFrame(step);
      else fromRef.current = target;
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return val;
}

// ---------- XP bar (segmented) ----------
function XPBar({ value, max, accent = '#fbbf24', height = 6, animated = true }) {
  const pct = Math.max(0, Math.min(1, value / max));
  return (
    <div className="xp-track relative" style={{ height }}>
      <div
        className={`xp-fill relative overflow-hidden ${animated ? 'xp-shimmer' : ''}`}
        style={{ width: `${pct * 100}%`, height: '100%' }}
      />
    </div>
  );
}

// ---------- Segmented bar ----------
function SegBar({ value, max = 10, color = '#fbbf24', glow }) {
  return (
    <div
      className="seg-bar"
      style={{ '--seg-color': color, '--seg-glow': glow || `${color}80` }}
    >
      {Array.from({ length: max }).map((_, i) => (
        <span key={i} className={`seg ${i < value ? 'on' : ''}`} />
      ))}
    </div>
  );
}

// ---------- Progress ring (SVG) ----------
function ProgressRing({ size = 140, stroke = 10, value = 0.6, color = '#34d399', glow, children }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const animated = useAnimatedNumber(value, 900);
  const offset = c * (1 - Math.max(0, Math.min(1, animated)));
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="rotate-[-90deg]">
        <defs>
          <linearGradient id={`g-${color.replace('#','')}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={color} />
            <stop offset="100%" stopColor={color} stopOpacity="0.7" />
          </linearGradient>
        </defs>
        <circle
          cx={size / 2} cy={size / 2} r={r}
          fill="transparent" strokeWidth={stroke}
          className="ring-track"
        />
        <circle
          cx={size / 2} cy={size / 2} r={r}
          fill="transparent"
          stroke={`url(#g-${color.replace('#','')})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          className="ring-fill"
          style={{ filter: glow ? `drop-shadow(0 0 8px ${glow})` : 'none' }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">{children}</div>
    </div>
  );
}

// ---------- Sparkline ----------
function Sparkline({ data, color = '#34d399', height = 36, fill = true, width = 140 }) {
  const path = useMemo(() => {
    if (!data.length) return '';
    const min = Math.min(...data);
    const max = Math.max(...data);
    const span = max - min || 1;
    const w = width;
    const h = height;
    const step = w / (data.length - 1);
    return data
      .map((v, i) => {
        const x = i * step;
        const y = h - ((v - min) / span) * (h - 4) - 2;
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`;
      })
      .join(' ');
  }, [data, width, height]);

  const area = useMemo(() => {
    if (!path) return '';
    return `${path} L ${width} ${height} L 0 ${height} Z`;
  }, [path, width, height]);

  const gid = `spark-${color.replace('#','')}-${Math.random().toString(36).slice(2,7)}`;
  return (
    <svg width={width} height={height} className="overflow-visible">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {fill && <path d={area} fill={`url(#${gid})`} />}
      <path d={path} stroke={color} strokeWidth="1.75" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// ---------- Quest checkbox row ----------
function QuestRow({ id, label, sub, xp, checked, onToggle, accent = '#f97316' }) {
  return (
    <label
      htmlFor={id}
      className="quest-row flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer"
    >
      <input
        id={id}
        type="checkbox"
        className="quest-check"
        checked={checked}
        onChange={() => onToggle && onToggle(id)}
        style={{ '--accent': accent, '--accent-glow': `${accent}66` }}
      />
      <div className="flex-1 min-w-0">
        <div className={`text-[13.5px] truncate ${checked ? 'line-through' : ''}`} style={{ color: checked ? 'var(--text-2)' : 'var(--text-0)' }}>
          {label}
        </div>
        {sub ? (
          <div className="text-[11px] mt-0.5 num" style={{ color: 'var(--text-2)' }}>{sub}</div>
        ) : null}
      </div>
      <div
        className="text-[11px] num font-semibold px-2 py-1 rounded-md"
        style={{
          color: accent,
          background: `${accent}14`,
          border: `1px solid ${accent}26`,
        }}
      >
        +{xp} XP
      </div>
    </label>
  );
}

// ---------- Stat tile ----------
function Stat({ label, value, unit, sub, delta, color, icon }) {
  const positive = (delta || '').toString().startsWith('+');
  const negative = (delta || '').toString().startsWith('-');
  return (
    <div className="rounded-2xl p-4 lift hairline border" style={{ background: 'rgba(255,255,255,0.02)' }}>
      <div className="flex items-start justify-between">
        <div className="text-[10px] uppercase tracking-[0.18em] num" style={{ color: 'var(--text-2)' }}>{label}</div>
        {icon ? <Icon name={icon} size={14} style={{ color: color || 'var(--text-2)' }} /> : null}
      </div>
      <div className="mt-2 flex items-baseline gap-1.5">
        <div className="num text-[26px] font-semibold" style={{ color: 'var(--text-0)' }}>{value}</div>
        {unit ? <div className="num text-[12px]" style={{ color: 'var(--text-2)' }}>{unit}</div> : null}
      </div>
      <div className="mt-1 flex items-center gap-2 text-[11px]">
        {delta ? (
          <span
            className="num inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md"
            style={{
              color: positive ? '#34d399' : negative ? '#f87171' : 'var(--text-2)',
              background: positive ? 'rgba(52,211,153,0.08)' : negative ? 'rgba(248,113,113,0.08)' : 'rgba(255,255,255,0.04)',
            }}
          >
            <Icon name={positive ? 'trending-up' : negative ? 'trending-down' : 'minus'} size={11} />
            {delta}
          </span>
        ) : null}
        {sub ? <span style={{ color: 'var(--text-2)' }}>{sub}</span> : null}
      </div>
    </div>
  );
}

// ---------- Level badge (hex) ----------
function LevelBadge({ level = 12, size = 44 }) {
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <div
        className="hex absolute inset-0"
        style={{
          background: 'linear-gradient(135deg, #fbbf24, #f97316)',
        }}
      />
      <div
        className="hex absolute"
        style={{
          inset: 2,
          background: '#0b0f18',
        }}
      />
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-[8px] uppercase num" style={{ color: '#fbbf24', letterSpacing: '0.18em', lineHeight: 1 }}>LVL</div>
        <div className="num text-[15px] font-bold leading-none mt-0.5" style={{ color: '#fff' }}>{level}</div>
      </div>
    </div>
  );
}

// ---------- Pill / Chip ----------
function Chip({ children, color = '#aab3c2', icon, className = '' }) {
  return (
    <span
      className={`inline-flex items-center gap-1 text-[11px] px-2 py-1 rounded-md num ${className}`}
      style={{
        color,
        background: `${color}14`,
        border: `1px solid ${color}26`,
      }}
    >
      {icon ? <Icon name={icon} size={12} /> : null}
      {children}
    </span>
  );
}

// ---------- Button ----------
function Button({ children, onClick, variant = 'primary', accent = '#fbbf24', icon, size = 'md', className = '', disabled }) {
  const base =
    'btn-primary inline-flex items-center justify-center gap-2 rounded-xl font-medium select-none transition-all';
  const sizes = {
    sm: 'text-[12px] px-3 py-1.5',
    md: 'text-[13px] px-4 py-2.5',
    lg: 'text-[14px] px-5 py-3',
  };
  const styles =
    variant === 'primary'
      ? {
          background: `linear-gradient(180deg, ${accent}, ${accent}cc)`,
          color: '#0a0d14',
          boxShadow: `0 4px 14px ${accent}33`,
        }
      : variant === 'ghost'
      ? {
          background: 'transparent',
          color: 'var(--text-0)',
          border: '1px solid var(--line-2)',
        }
      : {
          background: 'rgba(255,255,255,0.04)',
          color: 'var(--text-0)',
          border: '1px solid var(--line)',
        };
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${base} ${sizes[size]} ${className} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      style={styles}
    >
      {icon ? <Icon name={icon} size={size === 'sm' ? 13 : 15} /> : null}
      {children}
    </button>
  );
}

// ---------- Tab Group ----------
function Tabs({ tabs, value, onChange, accent = '#fbbf24' }) {
  return (
    <div className="inline-flex items-center gap-1 p-1 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid var(--line)' }}>
      {tabs.map((t) => {
        const active = value === t.id;
        return (
          <button
            key={t.id}
            onClick={() => onChange(t.id)}
            className="relative text-[12px] px-3 py-1.5 rounded-lg transition-colors num"
            style={{
              color: active ? '#0a0d14' : 'var(--text-1)',
              background: active ? accent : 'transparent',
              fontWeight: active ? 600 : 500,
            }}
          >
            {t.label}
          </button>
        );
      })}
    </div>
  );
}

// ---------- Toast (lightweight, in-page) ----------
function useToast() {
  const [toast, setToast] = useState(null);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3200);
    return () => clearTimeout(t);
  }, [toast]);
  const Toast = () =>
    toast ? (
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[90]">
        <div
          className="glass px-4 py-3 flex items-center gap-3"
          style={{
            border: `1px solid ${toast.color || '#fbbf24'}40`,
            boxShadow: `0 10px 40px ${toast.color || '#fbbf24'}26`,
          }}
        >
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: `${toast.color || '#fbbf24'}1f`, color: toast.color || '#fbbf24' }}
          >
            <Icon name={toast.icon || 'sparkles'} size={16} />
          </div>
          <div>
            <div className="text-[13px] font-semibold">{toast.title}</div>
            {toast.sub ? <div className="text-[11.5px]" style={{ color: 'var(--text-2)' }}>{toast.sub}</div> : null}
          </div>
        </div>
      </div>
    ) : null;
  return { show: setToast, Toast };
}

// ---------- Empty placeholder for imagery ----------
function PlaceholderImg({ label = 'Image', className = '', height = 120 }) {
  return (
    <div
      className={`rounded-xl flex items-center justify-center text-[11px] num ${className}`}
      style={{
        height,
        background:
          'repeating-linear-gradient(45deg, rgba(255,255,255,0.025) 0 6px, rgba(255,255,255,0.05) 6px 12px)',
        color: 'var(--text-2)',
        border: '1px dashed var(--line-2)',
      }}
    >
      {label}
    </div>
  );
}

Object.assign(window, {
  Icon, Card, SectionHeader, XPBar, SegBar, ProgressRing, Sparkline,
  QuestRow, Stat, LevelBadge, Chip, Button, Tabs, useToast, PlaceholderImg,
  useAnimatedNumber,
});
