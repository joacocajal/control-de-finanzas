// Views for the Ascend dashboard. All views read from / write to the top-level state passed in `state`.

const { useState: _useState, useEffect: _useEffect, useMemo: _useMemo } = React;

// =====================================================
// DASHBOARD VIEW
// =====================================================
function DashboardView({ state, dispatch, toast }) {
  const { user, finance, fitness, learning, quests, aiQuest } = state;

  return (
    <div className="grid grid-cols-12 gap-5 pb-12">
      {/* AI QUEST — full width */}
      <div className="col-span-12">
        <AIQuestCard aiQuest={aiQuest} dispatch={dispatch} toast={toast} />
      </div>

      {/* FINANCE */}
      <div className="col-span-12 lg:col-span-7">
        <FinanceWidget finance={finance} />
      </div>

      {/* STREAK + WEEKLY ACTIVITY */}
      <div className="col-span-12 lg:col-span-5">
        <WeeklyActivity user={user} />
      </div>

      {/* FITNESS */}
      <div className="col-span-12 lg:col-span-7">
        <FitnessWidget fitness={fitness} />
      </div>

      {/* LEARNING */}
      <div className="col-span-12 lg:col-span-5">
        <LearningWidget learning={learning} dispatch={dispatch} toast={toast} />
      </div>

      {/* TODAY'S QUESTS */}
      <div className="col-span-12">
        <QuestBoard quests={quests} dispatch={dispatch} toast={toast} />
      </div>
    </div>
  );
}

// ---------- AI Quest Card ----------
function AIQuestCard({ aiQuest, dispatch, toast }) {
  const [accepted, setAccepted] = _useState(false);

  const onAccept = () => {
    if (accepted) return;
    setAccepted(true);
    dispatch({ type: 'addXP', amount: 25 });
    toast({ title: 'Quest accepted', sub: '+25 XP — “' + aiQuest.title + '”', icon: 'sparkles', color: '#fbbf24' });
  };

  return (
    <div className="relative overflow-hidden rounded-[20px] glass aurora" data-screen-label="AI Quest">
      <div className="relative p-5 sm:p-6 flex flex-col sm:flex-row gap-5 items-stretch">
        {/* Left: AI orb */}
        <div className="flex sm:flex-col items-center sm:items-start gap-3 sm:gap-4 sm:w-[180px] shrink-0">
          <div className="relative">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center pulse-glow"
              style={{
                background:
                  'radial-gradient(circle at 30% 30%, #c4b5fd, #8b5cf6 45%, #6d28d9 80%)',
                '--glow': 'rgba(139,92,246,0.45)',
              }}
            >
              <Icon name="sparkles" size={22} style={{ color: '#fff' }} />
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase num tracking-[0.2em]" style={{ color: 'var(--text-2)' }}>AI Guide</div>
            <div className="display text-[15px] font-semibold leading-tight mt-0.5">Sage</div>
            <div className="text-[11px] mt-0.5 flex items-center gap-1.5" style={{ color: '#34d399' }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: '#34d399', boxShadow: '0 0 8px #34d399' }} />
              <span>Online · Tier IV</span>
            </div>
          </div>
        </div>

        {/* Center: quest text */}
        <div className="flex-1 min-w-0 sm:border-l sm:border-r hairline sm:px-6">
          <div className="flex items-center gap-2 mb-2">
            <Chip color="#8b5cf6" icon="zap">Daily Quest</Chip>
            <Chip color="#aab3c2" icon="clock">Resets in 06:42</Chip>
          </div>
          <div className="text-[18px] sm:text-[19px] display font-semibold leading-snug" style={{ color: 'var(--text-0)' }}>
            “{aiQuest.title}”
          </div>
          <div className="text-[13px] mt-1.5 max-w-prose" style={{ color: 'var(--text-1)' }}>
            {aiQuest.body}
          </div>
        </div>

        {/* Right: action */}
        <div className="flex sm:flex-col items-stretch sm:items-end gap-3 sm:w-[200px] shrink-0 justify-between">
          <div className="text-right">
            <div className="text-[10px] uppercase num tracking-[0.2em]" style={{ color: 'var(--text-2)' }}>Reward</div>
            <div className="flex items-baseline gap-1 justify-end mt-1">
              <div className="num text-[22px] font-bold" style={{ color: '#fbbf24' }}>+25</div>
              <div className="text-[11px] num" style={{ color: 'var(--text-2)' }}>XP</div>
            </div>
            <div className="text-[11px] num mt-0.5" style={{ color: 'var(--text-2)' }}>+1 ☉ Wisdom</div>
          </div>
          <Button
            onClick={onAccept}
            accent={accepted ? '#34d399' : '#fbbf24'}
            icon={accepted ? 'check' : 'swords'}
            size="md"
            className="w-full sm:w-auto"
          >
            {accepted ? 'Accepted' : 'Accept Quest'}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ---------- Finance Widget ----------
function FinanceWidget({ finance }) {
  const saved = finance.income - finance.expenses;
  const goalPct = Math.min(1, saved / finance.savingsGoal);
  return (
    <Card className="p-5">
      <SectionHeader
        kicker="Vault"
        title="Finances"
        icon="wallet"
        accent="#34d399"
        right={<Chip color="#34d399" icon="trending-up">+8.2% MoM</Chip>}
      />
      <div className="grid grid-cols-12 gap-4 mt-1">
        <div className="col-span-12 sm:col-span-7 grid grid-cols-2 gap-3">
          <Stat label="Income" value={`$${finance.income.toLocaleString()}`} sub="May" delta="+4.1%" color="#34d399" icon="arrow-down-to-line" />
          <Stat label="Expenses" value={`$${finance.expenses.toLocaleString()}`} sub="May" delta="-2.6%" color="#f87171" icon="arrow-up-from-line" />
          <Stat label="Saved" value={`$${saved.toLocaleString()}`} sub="this month" delta="+12.4%" color="#34d399" icon="piggy-bank" />
          <Stat label="Net worth" value={`$${(finance.netWorth/1000).toFixed(1)}k`} sub="all accounts" delta="+1.8%" color="#34d399" icon="landmark" />
        </div>
        <div className="col-span-12 sm:col-span-5 rounded-2xl p-4 hairline border dot-grid flex flex-col" style={{ background: 'rgba(52,211,153,0.04)' }}>
          <div className="text-[10px] uppercase num tracking-[0.18em]" style={{ color: 'var(--text-2)' }}>Savings goal · May</div>
          <div className="flex-1 flex items-center justify-center my-2">
            <ProgressRing size={150} stroke={11} value={goalPct} color="#34d399" glow="#34d39966">
              <div className="text-center">
                <div className="num text-[22px] font-bold" style={{ color: 'var(--text-0)' }}>{Math.round(goalPct*100)}%</div>
                <div className="text-[10px] num uppercase tracking-[0.18em]" style={{ color: 'var(--text-2)' }}>complete</div>
              </div>
            </ProgressRing>
          </div>
          <div className="flex justify-between text-[12px] num">
            <span style={{ color: 'var(--text-2)' }}>${saved.toLocaleString()} saved</span>
            <span style={{ color: 'var(--text-0)' }}>${finance.savingsGoal.toLocaleString()} goal</span>
          </div>
        </div>
      </div>

      {/* Mini ledger */}
      <div className="mt-4 grid grid-cols-3 gap-3">
        {finance.categories.map((c) => (
          <div key={c.name} className="rounded-xl p-3 hairline border lift" style={{ background: 'rgba(255,255,255,0.015)' }}>
            <div className="flex items-center justify-between">
              <div className="text-[12px]" style={{ color: 'var(--text-1)' }}>{c.name}</div>
              <div className="num text-[11px]" style={{ color: 'var(--text-2)' }}>{Math.round(c.value/c.budget*100)}%</div>
            </div>
            <div className="mt-2 num text-[16px] font-semibold">${c.value}<span className="text-[11px]" style={{ color: 'var(--text-2)' }}> / ${c.budget}</span></div>
            <div className="mt-2"><XPBar value={c.value} max={c.budget} animated={false} height={4} /></div>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ---------- Weekly Activity ----------
function WeeklyActivity({ user }) {
  // Active rings: move/exercise/study
  return (
    <Card className="p-5 h-full">
      <SectionHeader
        kicker="Cadence"
        title="This week"
        icon="activity"
        accent="#fbbf24"
        right={<Chip color="#f97316" icon="flame">{user.streak} day streak</Chip>}
      />
      <div className="grid grid-cols-7 gap-1.5 mt-2">
        {user.weekActivity.map((d, i) => {
          const intensity = Math.min(1, d.value);
          const bg = `rgba(251,191,36,${0.08 + intensity * 0.55})`;
          const today = i === user.todayIdx;
          return (
            <div key={i} className="text-center">
              <div className="text-[10px] num uppercase mb-1.5" style={{ color: today ? '#fbbf24' : 'var(--text-2)' }}>{d.day}</div>
              <div
                className="aspect-square rounded-lg flex items-center justify-center lift"
                style={{
                  background: bg,
                  border: today ? '1px solid #fbbf24' : '1px solid var(--line)',
                  boxShadow: today ? '0 0 20px rgba(251,191,36,0.25)' : 'none',
                }}
              >
                {d.value > 0.7 ? (
                  <Icon name="flame" size={14} className="flame" style={{ color: '#fbbf24' }} />
                ) : d.value > 0 ? (
                  <span className="num text-[10px]" style={{ color: 'var(--text-1)' }}>{Math.round(d.value*100)}</span>
                ) : (
                  <span className="text-[10px]" style={{ color: 'var(--text-2)' }}>—</span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-3 gap-3 mt-5">
        <RingMini label="Move" value={0.82} color="#34d399" sub="6.4 km" />
        <RingMini label="Lift" value={0.6} color="#8b5cf6" sub="3 / 5" />
        <RingMini label="Learn" value={0.45} color="#f97316" sub="45 min" />
      </div>

      <div className="mt-5 p-3 rounded-xl hairline border flex items-start gap-3" style={{ background: 'rgba(139,92,246,0.05)' }}>
        <div className="w-8 h-8 shrink-0 rounded-lg flex items-center justify-center" style={{ background: 'rgba(139,92,246,0.18)', color: '#8b5cf6' }}>
          <Icon name="trophy" size={15} />
        </div>
        <div className="min-w-0">
          <div className="text-[13px] font-semibold">Iron Pact · 5/7 done</div>
          <div className="text-[11.5px]" style={{ color: 'var(--text-1)' }}>Hit 4 workouts this week to keep your streak. <span style={{ color: '#fbbf24' }}>+150 XP</span></div>
        </div>
      </div>
    </Card>
  );
}

function RingMini({ label, value, color, sub }) {
  return (
    <div className="rounded-xl hairline border p-3 flex items-center gap-3 lift" style={{ background: 'rgba(255,255,255,0.015)' }}>
      <ProgressRing size={52} stroke={6} value={value} color={color} glow={`${color}66`}>
        <div className="num text-[11px] font-semibold">{Math.round(value*100)}</div>
      </ProgressRing>
      <div>
        <div className="text-[12px] font-medium">{label}</div>
        <div className="text-[11px] num" style={{ color: 'var(--text-2)' }}>{sub}</div>
      </div>
    </div>
  );
}

// ---------- Fitness Widget ----------
function FitnessWidget({ fitness }) {
  return (
    <Card className="p-5">
      <SectionHeader
        kicker="Forge"
        title="Fitness & Health"
        icon="dumbbell"
        accent="#8b5cf6"
        right={
          <div className="flex items-center gap-2">
            <Chip color="#8b5cf6" icon="heart-pulse">RHR 54</Chip>
            <Chip color="#38bdf8" icon="moon">7h 42m</Chip>
          </div>
        }
      />
      <div className="grid grid-cols-12 gap-4 mt-1">
        <div className="col-span-12 md:col-span-6 grid grid-cols-2 gap-3">
          <Stat label="Body weight" value={fitness.weight} unit="kg" delta="-0.4kg" sub="vs last wk" color="#34d399" icon="weight" />
          <Stat label="Calories in" value={fitness.calories} unit="kcal" delta="+120" sub="target 2,400" color="#8b5cf6" icon="utensils" />
          <Stat label="Steps" value={fitness.steps.toLocaleString()} unit="/ 10k" delta="+8%" color="#38bdf8" icon="footprints" />
          <Stat label="VO₂ max" value={fitness.vo2} unit="ml/kg" delta="+1.2" color="#34d399" icon="activity" />
        </div>

        {/* Personal Records */}
        <div className="col-span-12 md:col-span-6 rounded-2xl p-4 hairline border" style={{ background: 'linear-gradient(180deg, rgba(139,92,246,0.06), rgba(56,189,248,0.04))' }}>
          <div className="flex items-center justify-between mb-3">
            <div className="text-[10px] uppercase num tracking-[0.18em]" style={{ color: 'var(--text-2)' }}>Personal Records</div>
            <Chip color="#8b5cf6" icon="medal">3 new this month</Chip>
          </div>
          <div className="space-y-2.5">
            {fitness.prs.map((pr) => (
              <PRRow key={pr.lift} pr={pr} />
            ))}
          </div>
        </div>
      </div>

      {/* Cardio */}
      <div className="grid grid-cols-12 gap-3 mt-4">
        <CardioCard
          icon="footprints"
          color="#38bdf8"
          label="Running"
          metric={`${fitness.cardio.run.km} km`}
          pace={`${fitness.cardio.run.pace} /km · last 30d`}
          data={fitness.cardio.run.history}
        />
        <CardioCard
          icon="bike"
          color="#8b5cf6"
          label="Cycling"
          metric={`${fitness.cardio.bike.km} km`}
          pace={`${fitness.cardio.bike.avg} km/h avg · last 30d`}
          data={fitness.cardio.bike.history}
        />
        <CardioCard
          icon="waves"
          color="#34d399"
          label="Swim"
          metric={`${fitness.cardio.swim.m} m`}
          pace={`${fitness.cardio.swim.pace} /100m · last 30d`}
          data={fitness.cardio.swim.history}
        />
      </div>
    </Card>
  );
}

function PRRow({ pr }) {
  const pct = Math.min(1, pr.value / pr.target);
  return (
    <div className="flex items-center gap-3">
      <div
        className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
        style={{ background: `${pr.color}1f`, color: pr.color, border: `1px solid ${pr.color}33` }}
      >
        <Icon name={pr.icon} size={16} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline justify-between">
          <div className="text-[13px] font-medium">{pr.lift}</div>
          <div className="num text-[13px] font-semibold" style={{ color: pr.color }}>
            {pr.value}<span className="text-[11px]" style={{ color: 'var(--text-2)' }}> {pr.unit}</span>
          </div>
        </div>
        <div className="mt-1.5"><XPBar value={pct*100} max={100} accent={pr.color} animated={false} height={5} /></div>
        <div className="flex justify-between mt-1">
          <div className="text-[10px] num uppercase tracking-wider" style={{ color: 'var(--text-2)' }}>Tier {pr.tier}</div>
          <div className="text-[10px] num" style={{ color: 'var(--text-2)' }}>next: {pr.target}{pr.unit}</div>
        </div>
      </div>
    </div>
  );
}

function CardioCard({ icon, color, label, metric, pace, data }) {
  return (
    <div className="col-span-12 sm:col-span-4 rounded-2xl p-4 hairline border lift" style={{ background: 'rgba(255,255,255,0.015)' }}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${color}1f`, color }}>
            <Icon name={icon} size={14} />
          </div>
          <div className="text-[12.5px] font-medium">{label}</div>
        </div>
        <Sparkline data={data} color={color} width={86} height={28} />
      </div>
      <div className="mt-2 num text-[20px] font-semibold">{metric}</div>
      <div className="text-[11px] num" style={{ color: 'var(--text-2)' }}>{pace}</div>
    </div>
  );
}

// ---------- Learning Widget ----------
function LearningWidget({ learning, dispatch, toast }) {
  const toggle = (qId, taskId, xp, label) => {
    dispatch({ type: 'toggleLearningTask', skillId: qId, taskId });
    const target = learning.skills.find(s => s.id === qId).tasks.find(t => t.id === taskId);
    if (!target.done) {
      // about to flip to true
      dispatch({ type: 'addXP', amount: xp });
      toast({ title: `+${xp} XP — ${label}`, sub: 'Session logged. Keep ascending.', icon: 'book-open', color: '#f97316' });
    }
  };

  return (
    <Card className="p-5 h-full">
      <SectionHeader
        kicker="Codex"
        title="Learning Hub"
        icon="book-open"
        accent="#f97316"
        right={<Chip color="#f97316" icon="layers">{learning.skills.length} active paths</Chip>}
      />

      <div className="space-y-4 mt-1">
        {learning.skills.map((s) => (
          <div key={s.id} className="rounded-2xl hairline border p-3.5" style={{ background: 'rgba(249,115,22,0.03)' }}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${s.color}1f`, color: s.color, border: `1px solid ${s.color}33` }}>
                <Icon name={s.icon} size={18} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline justify-between gap-2">
                  <div className="text-[14px] font-semibold truncate">{s.name}</div>
                  <div className="num text-[11px]" style={{ color: 'var(--text-2)' }}>
                    LVL {s.level} · {s.xp}/{s.xpMax} XP
                  </div>
                </div>
                <div className="text-[11.5px] mt-0.5 truncate" style={{ color: 'var(--text-2)' }}>{s.path}</div>
                <div className="mt-2"><XPBar value={s.xp} max={s.xpMax} accent={s.color} height={5} /></div>
              </div>
            </div>
            <div className="mt-2 space-y-0.5">
              {s.tasks.map((t) => (
                <QuestRow
                  key={t.id}
                  id={`lt-${s.id}-${t.id}`}
                  label={t.label}
                  sub={t.sub}
                  xp={t.xp}
                  checked={t.done}
                  onToggle={() => toggle(s.id, t.id, t.xp, t.label)}
                  accent={s.color}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

// ---------- Quest Board ----------
function QuestBoard({ quests, dispatch, toast }) {
  const groups = [
    { id: 'daily', title: 'Daily Quests', icon: 'sun', color: '#fbbf24', items: quests.daily },
    { id: 'weekly', title: 'Weekly Missions', icon: 'calendar', color: '#8b5cf6', items: quests.weekly },
    { id: 'epic', title: 'Epic Goals', icon: 'crown', color: '#f97316', items: quests.epic },
  ];

  const onToggle = (group, id, xp, label) => {
    const item = quests[group].find((q) => q.id === id);
    dispatch({ type: 'toggleQuest', group, id });
    if (!item.done) {
      dispatch({ type: 'addXP', amount: xp });
      toast({ title: `+${xp} XP — ${label}`, icon: 'sparkles', color: '#fbbf24' });
    }
  };

  return (
    <Card className="p-5">
      <SectionHeader
        kicker="Adventure log"
        title="Today's Quests"
        icon="scroll-text"
        accent="#fbbf24"
        right={
          <div className="flex items-center gap-2">
            <Chip color="#aab3c2" icon="filter">All paths</Chip>
            <Button variant="ghost" icon="plus" size="sm">New quest</Button>
          </div>
        }
      />
      <div className="grid grid-cols-12 gap-4 mt-2">
        {groups.map((g) => (
          <div key={g.id} className="col-span-12 lg:col-span-4 rounded-2xl hairline border p-4" style={{ background: 'rgba(255,255,255,0.015)' }}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${g.color}1f`, color: g.color }}>
                  <Icon name={g.icon} size={14} />
                </div>
                <div className="text-[13px] font-semibold">{g.title}</div>
              </div>
              <div className="text-[11px] num" style={{ color: 'var(--text-2)' }}>
                {g.items.filter(i=>i.done).length}/{g.items.length}
              </div>
            </div>
            <div className="space-y-1">
              {g.items.map((q) => (
                <QuestRow
                  key={q.id}
                  id={`q-${g.id}-${q.id}`}
                  label={q.label}
                  sub={q.sub}
                  xp={q.xp}
                  checked={q.done}
                  accent={g.color}
                  onToggle={() => onToggle(g.id, q.id, q.xp, q.label)}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

// =====================================================
// FINANCES VIEW
// =====================================================
function FinancesView({ state }) {
  const f = state.finance;
  return (
    <div className="grid grid-cols-12 gap-5 pb-12">
      <div className="col-span-12">
        <Card className="p-5 dot-grid" data-screen-label="Finances · Overview">
          <SectionHeader kicker="May 2026" title="Vault overview" icon="wallet" accent="#34d399" right={<Tabs tabs={[{id:'m',label:'Month'},{id:'q',label:'Quarter'},{id:'y',label:'Year'}]} value="m" onChange={()=>{}} accent="#34d399" />} />
          <div className="grid grid-cols-12 gap-4 mt-1">
            <div className="col-span-12 lg:col-span-8 grid grid-cols-4 gap-3">
              <Stat label="Income" value={`$${f.income.toLocaleString()}`} delta="+4.1%" color="#34d399" icon="arrow-down-to-line" />
              <Stat label="Expenses" value={`$${f.expenses.toLocaleString()}`} delta="-2.6%" color="#f87171" icon="arrow-up-from-line" />
              <Stat label="Saved" value={`$${(f.income-f.expenses).toLocaleString()}`} delta="+12.4%" color="#34d399" icon="piggy-bank" />
              <Stat label="Net worth" value={`$${(f.netWorth/1000).toFixed(1)}k`} delta="+1.8%" color="#34d399" icon="landmark" />
              <div className="col-span-4 rounded-2xl hairline border p-4" style={{ background: 'rgba(255,255,255,0.015)' }}>
                <div className="flex items-center justify-between mb-3">
                  <div className="text-[10px] num uppercase tracking-[0.18em]" style={{ color: 'var(--text-2)' }}>Cashflow · last 12 months</div>
                  <div className="flex gap-2">
                    <Chip color="#34d399" icon="circle">Income</Chip>
                    <Chip color="#f87171" icon="circle">Expenses</Chip>
                  </div>
                </div>
                <CashflowChart data={f.history} />
              </div>
            </div>
            <div className="col-span-12 lg:col-span-4 rounded-2xl hairline border p-4 flex flex-col items-center" style={{ background: 'rgba(52,211,153,0.05)' }}>
              <div className="text-[10px] num uppercase tracking-[0.18em] self-start" style={{ color: 'var(--text-2)' }}>Savings goal · May</div>
              <div className="flex-1 my-4">
                <ProgressRing size={180} stroke={14} value={(f.income-f.expenses)/f.savingsGoal} color="#34d399" glow="#34d39966">
                  <div className="text-center">
                    <div className="num text-[28px] font-bold">{Math.round((f.income-f.expenses)/f.savingsGoal*100)}%</div>
                    <div className="text-[10px] num uppercase tracking-[0.18em]" style={{ color: 'var(--text-2)' }}>of $2,500</div>
                  </div>
                </ProgressRing>
              </div>
              <Button accent="#34d399" icon="target" size="sm" className="w-full">Adjust goal</Button>
            </div>
          </div>
        </Card>
      </div>

      <div className="col-span-12 lg:col-span-7">
        <Card className="p-5">
          <SectionHeader kicker="Allocation" title="Budget categories" icon="pie-chart" accent="#34d399" />
          <div className="grid grid-cols-2 gap-3">
            {f.categories.concat([
              { name: 'Subscriptions', value: 89, budget: 100 },
              { name: 'Travel', value: 320, budget: 500 },
              { name: 'Health', value: 145, budget: 200 },
            ]).map((c, idx) => (
              <div key={idx} className="rounded-xl p-3 hairline border lift" style={{ background: 'rgba(255,255,255,0.015)' }}>
                <div className="flex items-baseline justify-between">
                  <div className="text-[12.5px] font-medium">{c.name}</div>
                  <div className="num text-[11px]" style={{ color: c.value/c.budget>0.9?'#f87171':'var(--text-2)' }}>{Math.round(c.value/c.budget*100)}%</div>
                </div>
                <div className="num text-[18px] font-semibold mt-1">${c.value}<span className="text-[11px]" style={{ color: 'var(--text-2)' }}> / ${c.budget}</span></div>
                <div className="mt-2"><XPBar value={c.value} max={c.budget} accent={c.value/c.budget>0.9?'#f87171':'#34d399'} animated={false} height={5} /></div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="col-span-12 lg:col-span-5">
        <Card className="p-5 h-full">
          <SectionHeader kicker="Ledger" title="Recent transactions" icon="receipt" accent="#34d399" />
          <div className="divide-y divide-white/[0.04]">
            {f.transactions.map((t) => (
              <div key={t.id} className="flex items-center gap-3 py-2.5">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.04)', color: 'var(--text-1)' }}>
                  <Icon name={t.icon} size={14} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[12.5px] truncate">{t.label}</div>
                  <div className="text-[11px] num" style={{ color: 'var(--text-2)' }}>{t.cat} · {t.date}</div>
                </div>
                <div className="num text-[13px] font-semibold" style={{ color: t.amount > 0 ? '#34d399' : 'var(--text-0)' }}>
                  {t.amount > 0 ? '+' : ''}${Math.abs(t.amount).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function CashflowChart({ data }) {
  const W = 540, H = 160, P = 16;
  const max = Math.max(...data.flatMap(d => [d.in, d.out]));
  const step = (W - P*2) / (data.length - 1);
  const toY = (v) => H - P - (v / max) * (H - P*2);
  const inPath = data.map((d,i)=>`${i===0?'M':'L'} ${P + i*step} ${toY(d.in)}`).join(' ');
  const outPath = data.map((d,i)=>`${i===0?'M':'L'} ${P + i*step} ${toY(d.out)}`).join(' ');
  const inArea = `${inPath} L ${P + (data.length-1)*step} ${H-P} L ${P} ${H-P} Z`;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" preserveAspectRatio="none" style={{ height: H }}>
      <defs>
        <linearGradient id="cf-in" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#34d399" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#34d399" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0.25,0.5,0.75].map((g,i)=>(
        <line key={i} x1={P} x2={W-P} y1={P + g*(H-P*2)} y2={P + g*(H-P*2)} stroke="rgba(255,255,255,0.04)" strokeDasharray="2 4" />
      ))}
      <path d={inArea} fill="url(#cf-in)" />
      <path d={inPath} stroke="#34d399" strokeWidth="2" fill="none" />
      <path d={outPath} stroke="#f87171" strokeWidth="1.5" fill="none" strokeDasharray="3 3" />
      {data.map((d,i)=>(
        <g key={i}>
          <text x={P + i*step} y={H-2} textAnchor="middle" fontSize="9" fill="rgba(255,255,255,0.4)" style={{fontFamily:'JetBrains Mono'}}>{d.m}</text>
        </g>
      ))}
    </svg>
  );
}

// =====================================================
// FITNESS VIEW
// =====================================================
function FitnessView({ state }) {
  const f = state.fitness;
  return (
    <div className="grid grid-cols-12 gap-5 pb-12" data-screen-label="Fitness · Forge">
      <div className="col-span-12">
        <Card className="p-5">
          <SectionHeader kicker="The Forge" title="Body composition & vitals" icon="dumbbell" accent="#8b5cf6"
            right={<Tabs tabs={[{id:'w',label:'Week'},{id:'m',label:'Month'},{id:'q',label:'Quarter'}]} value="m" onChange={()=>{}} accent="#8b5cf6"/>}
          />
          <div className="grid grid-cols-12 gap-3 mt-1">
            <div className="col-span-12 md:col-span-3"><Stat label="Body weight" value={f.weight} unit="kg" delta="-0.4kg" sub="vs last wk" color="#34d399" icon="weight" /></div>
            <div className="col-span-12 md:col-span-3"><Stat label="Body fat" value="14.2" unit="%" delta="-0.6%" color="#34d399" icon="droplet" /></div>
            <div className="col-span-12 md:col-span-3"><Stat label="Resting HR" value="54" unit="bpm" delta="-2" color="#34d399" icon="heart-pulse" /></div>
            <div className="col-span-12 md:col-span-3"><Stat label="Sleep" value="7h 42m" delta="+18m" color="#34d399" icon="moon" /></div>
          </div>
        </Card>
      </div>

      <div className="col-span-12 lg:col-span-7">
        <Card className="p-5">
          <SectionHeader kicker="Iron" title="Personal records" icon="medal" accent="#8b5cf6" right={<Chip color="#8b5cf6" icon="trending-up">+3 PRs this month</Chip>} />
          <div className="grid grid-cols-2 gap-3 mt-1">
            {f.prs.concat([
              { lift: 'Overhead Press', value: 65, unit: 'kg', target: 70, color: '#38bdf8', icon: 'arrow-up', tier: 'III' },
              { lift: 'Pull-ups (BW+)', value: 25, unit: 'kg', target: 30, color: '#34d399', icon: 'arrow-big-up-dash', tier: 'III' },
            ]).map((pr) => (
              <div key={pr.lift} className="rounded-2xl hairline border p-3.5 lift" style={{ background: 'rgba(255,255,255,0.015)' }}>
                <PRRow pr={pr} />
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="col-span-12 lg:col-span-5">
        <Card className="p-5 h-full">
          <SectionHeader kicker="Today" title="Macros" icon="utensils" accent="#8b5cf6" />
          <div className="flex items-center justify-center my-2">
            <ProgressRing size={170} stroke={12} value={f.calories/2400} color="#8b5cf6" glow="#8b5cf666">
              <div className="text-center">
                <div className="num text-[26px] font-bold">{f.calories}</div>
                <div className="text-[10px] num uppercase tracking-[0.18em]" style={{ color: 'var(--text-2)' }}>of 2,400 kcal</div>
              </div>
            </ProgressRing>
          </div>
          <div className="grid grid-cols-3 gap-2 mt-2">
            {[
              { label: 'Protein', value: 168, max: 200, color: '#34d399', unit: 'g' },
              { label: 'Carbs', value: 220, max: 280, color: '#fbbf24', unit: 'g' },
              { label: 'Fats', value: 62, max: 80, color: '#f97316', unit: 'g' },
            ].map((m) => (
              <div key={m.label} className="rounded-xl p-2.5 hairline border" style={{ background: 'rgba(255,255,255,0.015)' }}>
                <div className="text-[10px] num uppercase tracking-wider" style={{ color: 'var(--text-2)' }}>{m.label}</div>
                <div className="num text-[15px] font-semibold mt-0.5">{m.value}<span className="text-[10px]" style={{ color: 'var(--text-2)' }}>{m.unit}</span></div>
                <div className="mt-2"><XPBar value={m.value} max={m.max} accent={m.color} animated={false} height={4} /></div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="col-span-12">
        <Card className="p-5">
          <SectionHeader kicker="Cardio" title="30-day endurance" icon="activity" accent="#38bdf8" />
          <div className="grid grid-cols-12 gap-3">
            <CardioCard icon="footprints" color="#38bdf8" label="Running" metric={`${f.cardio.run.km} km`} pace={`${f.cardio.run.pace} /km · last 30d`} data={f.cardio.run.history} />
            <CardioCard icon="bike" color="#8b5cf6" label="Cycling" metric={`${f.cardio.bike.km} km`} pace={`${f.cardio.bike.avg} km/h avg · last 30d`} data={f.cardio.bike.history} />
            <CardioCard icon="waves" color="#34d399" label="Swim" metric={`${f.cardio.swim.m} m`} pace={`${f.cardio.swim.pace} /100m · last 30d`} data={f.cardio.swim.history} />
          </div>
        </Card>
      </div>
    </div>
  );
}

// =====================================================
// LEARNING VIEW
// =====================================================
function LearningView({ state, dispatch, toast }) {
  return (
    <div className="grid grid-cols-12 gap-5 pb-12" data-screen-label="Learning Hub">
      <div className="col-span-12">
        <Card className="p-5">
          <SectionHeader kicker="Codex" title="Skill paths" icon="book-open" accent="#f97316" right={<Button accent="#f97316" icon="plus" size="sm">Add path</Button>} />
          <div className="grid grid-cols-12 gap-3">
            {state.learning.skills.map((s) => (
              <div key={s.id} className="col-span-12 md:col-span-6 rounded-2xl hairline border p-4 lift" style={{ background: `linear-gradient(180deg, ${s.color}0d, transparent)` }}>
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${s.color}1f`, color: s.color, border: `1px solid ${s.color}33` }}>
                    <Icon name={s.icon} size={20} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline justify-between">
                      <div className="text-[15px] font-semibold">{s.name}</div>
                      <div className="num text-[11px]" style={{ color: 'var(--text-2)' }}>LVL {s.level}</div>
                    </div>
                    <div className="text-[11.5px]" style={{ color: 'var(--text-2)' }}>{s.path}</div>
                  </div>
                </div>
                <div className="mt-3"><XPBar value={s.xp} max={s.xpMax} accent={s.color} height={6} /></div>
                <div className="flex justify-between mt-1 text-[11px] num" style={{ color: 'var(--text-2)' }}>
                  <span>{s.xp} XP</span>
                  <span>{s.xpMax - s.xp} to LVL {s.level+1}</span>
                </div>
                <div className="mt-3 space-y-0.5">
                  {s.tasks.map((t) => (
                    <QuestRow
                      key={t.id}
                      id={`lv-${s.id}-${t.id}`}
                      label={t.label}
                      sub={t.sub}
                      xp={t.xp}
                      checked={t.done}
                      accent={s.color}
                      onToggle={() => {
                        const target = state.learning.skills.find(x=>x.id===s.id).tasks.find(x=>x.id===t.id);
                        dispatch({ type: 'toggleLearningTask', skillId: s.id, taskId: t.id });
                        if (!target.done) {
                          dispatch({ type: 'addXP', amount: t.xp });
                          toast({ title: `+${t.xp} XP`, sub: t.label, icon: 'book-open', color: '#f97316' });
                        }
                      }}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="col-span-12 lg:col-span-7">
        <Card className="p-5">
          <SectionHeader kicker="Library" title="Currently consuming" icon="library" accent="#f97316" />
          <div className="grid grid-cols-12 gap-3">
            {state.learning.library.map((b) => (
              <div key={b.id} className="col-span-12 sm:col-span-6 flex gap-3 rounded-xl hairline border p-3 lift" style={{ background: 'rgba(255,255,255,0.015)' }}>
                <PlaceholderImg label={b.kind} className="w-16 shrink-0" height={80} />
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] num uppercase tracking-[0.18em]" style={{ color: 'var(--text-2)' }}>{b.kind}</div>
                  <div className="text-[13px] font-semibold truncate">{b.title}</div>
                  <div className="text-[11px] truncate" style={{ color: 'var(--text-1)' }}>{b.author}</div>
                  <div className="mt-2"><XPBar value={b.progress} max={100} accent="#f97316" animated={false} height={4} /></div>
                  <div className="text-[10px] num mt-1" style={{ color: 'var(--text-2)' }}>{b.progress}% · {b.left}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="col-span-12 lg:col-span-5">
        <Card className="p-5 h-full">
          <SectionHeader kicker="Mastered" title="Skill tree" icon="git-branch" accent="#f97316" />
          <div className="space-y-2 mt-1">
            {state.learning.mastered.map((m) => (
              <div key={m.name} className="flex items-center gap-3 p-2.5 rounded-xl hairline border" style={{ background: 'rgba(249,115,22,0.04)' }}>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'rgba(249,115,22,0.18)', color: '#f97316' }}>
                  <Icon name="check" size={14} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[12.5px] font-medium truncate">{m.name}</div>
                  <div className="text-[11px] num" style={{ color: 'var(--text-2)' }}>{m.kind} · {m.when}</div>
                </div>
                <Chip color="#f97316" icon="star">+{m.xp}</Chip>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

// =====================================================
// AI ARENA VIEW
// =====================================================
function ArenaView({ state, dispatch, toast }) {
  const [input, setInput] = _useState('');
  const [messages, setMessages] = _useState([
    { role: 'sage', text: 'Greetings, traveler. Today the path is forged in iron and ink. What discipline would you train?' },
  ]);
  const [busy, setBusy] = _useState(false);

  const send = async () => {
    const q = input.trim();
    if (!q || busy) return;
    setMessages((m) => [...m, { role: 'user', text: q }]);
    setInput('');
    setBusy(true);
    try {
      const reply = await window.claude.complete(
        `You are "Sage", an AI guide in a gamified personal development RPG dashboard. ` +
        `Respond in 2-3 sentences, with warm but firm tone, occasionally using gamified words ` +
        `(quest, forge, codex, tier, ascend). The user is LVL ${state.user.level}, streak ${state.user.streak} days. ` +
        `User said: "${q}". Reply only with the message text.`
      );
      setMessages((m) => [...m, { role: 'sage', text: reply.trim() }]);
    } catch (e) {
      setMessages((m) => [...m, { role: 'sage', text: 'The aether falters. Try again in a moment.' }]);
    } finally {
      setBusy(false);
    }
  };

  const agents = [
    { name: 'Sage', role: 'Daily Guide', color: '#8b5cf6', icon: 'sparkles', tier: 'IV', desc: 'Crafts your daily quest. Reads your streaks, energy, and gaps in the codex.' },
    { name: 'Atlas', role: 'Strength Coach', color: '#38bdf8', icon: 'dumbbell', tier: 'III', desc: 'Plans your lifts. Suggests deloads when fatigue spikes.' },
    { name: 'Mint', role: 'Coin Steward', color: '#34d399', icon: 'wallet', tier: 'III', desc: 'Watches your vault. Flags drift from savings goals before month-end.' },
    { name: 'Lumen', role: 'Codex Tutor', color: '#f97316', icon: 'book-open', tier: 'II', desc: 'Curates your reading queue and quizzes you on retention.' },
  ];

  return (
    <div className="grid grid-cols-12 gap-5 pb-12" data-screen-label="AI Agent Arena">
      <div className="col-span-12">
        <Card className="p-5 aurora">
          <SectionHeader kicker="Council" title="Your AI Agents" icon="users" accent="#8b5cf6" right={<Chip color="#8b5cf6" icon="zap">4 active</Chip>} />
          <div className="grid grid-cols-12 gap-3">
            {agents.map((a) => (
              <div key={a.name} className="col-span-12 sm:col-span-6 lg:col-span-3 rounded-2xl hairline border p-4 lift" style={{ background: `linear-gradient(180deg, ${a.color}10, rgba(255,255,255,0.01))` }}>
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ background: `${a.color}1f`, color: a.color, border: `1px solid ${a.color}33` }}>
                    <Icon name={a.icon} size={20} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[14px] font-semibold">{a.name}</div>
                    <div className="text-[11px] num" style={{ color: 'var(--text-2)' }}>{a.role} · Tier {a.tier}</div>
                  </div>
                </div>
                <div className="text-[11.5px] mt-2.5 leading-snug" style={{ color: 'var(--text-1)' }}>{a.desc}</div>
                <div className="mt-3 flex items-center gap-2">
                  <Button size="sm" variant="ghost" icon="message-circle">Brief</Button>
                  <div className="text-[10px] num flex items-center gap-1" style={{ color: '#34d399' }}>
                    <span className="w-1.5 h-1.5 rounded-full" style={{ background: '#34d399', boxShadow: '0 0 6px #34d399' }} />Online
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="col-span-12 lg:col-span-8">
        <Card className="p-0 overflow-hidden flex flex-col" style={{ minHeight: 520 }}>
          <div className="p-4 border-b hairline flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center pulse-glow"
              style={{ background: 'radial-gradient(circle at 30% 30%, #c4b5fd, #8b5cf6 45%, #6d28d9 80%)', '--glow': 'rgba(139,92,246,0.4)' }}
            >
              <Icon name="sparkles" size={16} style={{ color: '#fff' }} />
            </div>
            <div className="flex-1">
              <div className="text-[14px] font-semibold">Sage · AI Guide</div>
              <div className="text-[11px]" style={{ color: 'var(--text-2)' }}>Tier IV · Knows your level, streak & active quests</div>
            </div>
            <Chip color="#34d399" icon="circle">Live</Chip>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <ChatBubble key={i} role={m.role} text={m.text} />
            ))}
            {busy ? (
              <ChatBubble role="sage" text={<><span className="dot"></span><span className="dot"></span><span className="dot"></span></>} />
            ) : null}
          </div>
          <div className="p-3 border-t hairline flex items-center gap-2">
            <div className="flex-1 flex items-center gap-2 px-3 py-2 rounded-xl" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid var(--line)' }}>
              <Icon name="message-circle" size={14} style={{ color: 'var(--text-2)' }} />
              <input
                value={input}
                onChange={(e)=>setInput(e.target.value)}
                onKeyDown={(e)=>{ if (e.key==='Enter') send(); }}
                placeholder="Ask Sage to forge today's quest…"
                className="flex-1 bg-transparent outline-none text-[13px]"
                style={{ color: 'var(--text-0)' }}
              />
            </div>
            <Button onClick={send} accent="#8b5cf6" icon={busy?'loader':'send'} disabled={busy}>{busy?'Forging…':'Send'}</Button>
          </div>
        </Card>
      </div>

      <div className="col-span-12 lg:col-span-4">
        <Card className="p-5 h-full">
          <SectionHeader kicker="Quick" title="Forge a quest" icon="zap" accent="#8b5cf6" />
          <div className="space-y-2">
            {[
              { label: 'A 20-min reading sprint', icon: 'book-open', color: '#f97316' },
              { label: 'A challenging lift today', icon: 'dumbbell', color: '#8b5cf6' },
              { label: 'A no-spend afternoon', icon: 'wallet', color: '#34d399' },
              { label: 'A 10-min meditation', icon: 'wind', color: '#38bdf8' },
            ].map((s) => (
              <button
                key={s.label}
                onClick={() => { setInput(`Forge me ${s.label.toLowerCase()}.`); }}
                className="w-full flex items-center gap-3 p-2.5 rounded-xl quest-row text-left"
                style={{ border: '1px solid var(--line)', background: 'rgba(255,255,255,0.015)' }}
              >
                <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${s.color}1f`, color: s.color }}>
                  <Icon name={s.icon} size={14} />
                </div>
                <div className="text-[12.5px] flex-1">{s.label}</div>
                <Icon name="arrow-up-right" size={14} style={{ color: 'var(--text-2)' }} />
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function ChatBubble({ role, text }) {
  const isSage = role === 'sage';
  return (
    <div className={`flex gap-2.5 ${isSage ? '' : 'flex-row-reverse'}`}>
      <div
        className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
        style={isSage
          ? { background: 'radial-gradient(circle at 30% 30%, #c4b5fd, #8b5cf6)', color: '#fff' }
          : { background: 'rgba(255,255,255,0.06)', color: 'var(--text-1)' }
        }
      >
        <Icon name={isSage ? 'sparkles' : 'user'} size={13} />
      </div>
      <div
        className={`max-w-[78%] text-[13.5px] leading-relaxed px-3.5 py-2.5 rounded-2xl ${isSage ? 'rounded-tl-sm' : 'rounded-tr-sm'}`}
        style={isSage
          ? { background: 'rgba(139,92,246,0.10)', color: 'var(--text-0)', border: '1px solid rgba(139,92,246,0.2)' }
          : { background: 'rgba(255,255,255,0.05)', color: 'var(--text-0)', border: '1px solid var(--line)' }
        }
      >
        {text}
      </div>
    </div>
  );
}

Object.assign(window, {
  DashboardView, FinancesView, FitnessView, LearningView, ArenaView,
});
