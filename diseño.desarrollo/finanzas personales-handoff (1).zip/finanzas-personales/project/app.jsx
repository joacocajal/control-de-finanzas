// Main app shell: sidebar, header, state, view routing, and Tweaks.

const { useState: useS, useEffect: useE, useReducer, useMemo: useM } = React;

// ---------- Initial state ----------
const INITIAL_STATE = {
  user: {
    name: 'Lyra Okafor',
    handle: '@lyra',
    level: 12,
    xp: 1840,
    xpMax: 2400,
    streak: 23,
    todayIdx: 4, // Fri
    weekActivity: [
      { day: 'M', value: 0.85 },
      { day: 'T', value: 0.55 },
      { day: 'W', value: 0.92 },
      { day: 'T', value: 0.6 },
      { day: 'F', value: 0.78 },
      { day: 'S', value: 0 },
      { day: 'S', value: 0 },
    ],
  },
  finance: {
    income: 6420,
    expenses: 3870,
    netWorth: 48320,
    savingsGoal: 2500,
    categories: [
      { name: 'Rent & Utilities', value: 1600, budget: 1700 },
      { name: 'Food & Drink', value: 540, budget: 600 },
      { name: 'Transport', value: 210, budget: 250 },
    ],
    transactions: [
      { id: 1, label: 'Salary — Helix Labs', cat: 'Income', date: 'May 15', amount: 6420, icon: 'briefcase' },
      { id: 2, label: 'Grocery — Bear Market', cat: 'Food', date: 'May 14', amount: -84.20, icon: 'shopping-bag' },
      { id: 3, label: 'Index fund — VTSAX', cat: 'Invest', date: 'May 12', amount: -800, icon: 'trending-up' },
      { id: 4, label: 'Coffee — Roastery', cat: 'Food', date: 'May 12', amount: -6.50, icon: 'coffee' },
      { id: 5, label: 'Gym — Iron Cathedral', cat: 'Health', date: 'May 10', amount: -49, icon: 'dumbbell' },
      { id: 6, label: 'Spotify Family', cat: 'Subs', date: 'May 09', amount: -16.99, icon: 'music' },
      { id: 7, label: 'Book — Atomic Habits', cat: 'Learn', date: 'May 08', amount: -14.20, icon: 'book' },
    ],
    history: [
      { m: 'Jun', in: 6200, out: 4100 },
      { m: 'Jul', in: 6200, out: 3900 },
      { m: 'Aug', in: 6300, out: 4200 },
      { m: 'Sep', in: 6300, out: 4350 },
      { m: 'Oct', in: 6420, out: 4100 },
      { m: 'Nov', in: 6420, out: 4500 },
      { m: 'Dec', in: 7200, out: 5200 },
      { m: 'Jan', in: 6420, out: 4000 },
      { m: 'Feb', in: 6420, out: 3850 },
      { m: 'Mar', in: 6420, out: 4150 },
      { m: 'Apr', in: 6420, out: 3970 },
      { m: 'May', in: 6420, out: 3870 },
    ],
  },
  fitness: {
    weight: 72.4,
    calories: 1840,
    steps: 8420,
    vo2: 48.6,
    prs: [
      { lift: 'Back Squat', value: 142, unit: 'kg', target: 150, color: '#8b5cf6', icon: 'arrow-big-down-dash', tier: 'IV' },
      { lift: 'Bench Press', value: 102, unit: 'kg', target: 110, color: '#f97316', icon: 'arrow-down-up', tier: 'III' },
      { lift: 'Deadlift', value: 180, unit: 'kg', target: 200, color: '#34d399', icon: 'arrow-up', tier: 'IV' },
    ],
    cardio: {
      run: { km: 42.3, pace: '5:08', history: [3,2,4,3,5,4,6,5,4,7,6,5,8,6] },
      bike: { km: 86.5, avg: 28.2, history: [10,8,12,9,15,11,14,18,16,12,17] },
      swim: { m: 4200, pace: '1:58', history: [200,250,300,350,400,420,500,480,520,600,700] },
    },
  },
  learning: {
    skills: [
      {
        id: 'ml',
        name: 'Machine Learning',
        path: 'Foundations · Stanford CS229 track',
        level: 4,
        xp: 320,
        xpMax: 500,
        color: '#f97316',
        icon: 'brain-circuit',
        tasks: [
          { id: 1, label: 'Watch lecture 8: SVMs', sub: '~38 min', xp: 30, done: false },
          { id: 2, label: 'Solve problem set 4 (q1-3)', sub: 'paper & code', xp: 50, done: true },
          { id: 3, label: 'Write summary in Codex', sub: '300 words', xp: 20, done: false },
        ],
      },
      {
        id: 'es',
        name: 'Spanish — B2',
        path: 'Conversational fluency · 90-day arc',
        level: 7,
        xp: 410,
        xpMax: 600,
        color: '#fbbf24',
        icon: 'languages',
        tasks: [
          { id: 1, label: 'Anki review (40 cards)', sub: '~10 min', xp: 15, done: true },
          { id: 2, label: 'iTalki lesson with Andrés', sub: '45 min @ 18:00', xp: 60, done: false },
          { id: 3, label: 'Read 2 pages of "La Sombra…"', sub: 'pages 84-86', xp: 25, done: false },
        ],
      },
    ],
    library: [
      { id: 1, kind: 'Book', title: 'Thinking in Systems', author: 'Donella Meadows', progress: 62, left: '~2h left' },
      { id: 2, kind: 'Course', title: 'Statistical Inference', author: 'Coursera · JHU', progress: 38, left: '4 modules' },
      { id: 3, kind: 'Paper', title: 'Attention Is All You Need', author: 'Vaswani et al., 2017', progress: 85, left: '14m left' },
      { id: 4, kind: 'Podcast', title: 'The Knowledge Project', author: 'Ep. 184 · Naval', progress: 24, left: '52m left' },
    ],
    mastered: [
      { name: 'SQL — Window functions', kind: 'Skill', when: '3 weeks ago', xp: 120 },
      { name: 'React Server Components', kind: 'Course', when: 'Last month', xp: 220 },
      { name: 'Marathon — 4:12:08', kind: 'Achievement', when: '2 months ago', xp: 500 },
    ],
  },
  quests: {
    daily: [
      { id: 1, label: 'Drink 3L of water', sub: 'Today · 1.8L logged', xp: 10, done: false },
      { id: 2, label: '20-min meditation', sub: 'morning', xp: 15, done: true },
      { id: 3, label: 'Review yesterday\'s Codex notes', sub: 'spaced repetition', xp: 20, done: false },
      { id: 4, label: 'Walk 8,000 steps', sub: '8,420 / 8,000', xp: 15, done: true },
    ],
    weekly: [
      { id: 1, label: 'Hit 4 strength sessions', sub: '3 / 4 · 2 days left', xp: 150, done: false },
      { id: 2, label: 'Stay under $600 on food', sub: '$540 spent', xp: 100, done: false },
      { id: 3, label: 'Finish ML PSet 4', sub: 'due Sunday', xp: 200, done: false },
    ],
    epic: [
      { id: 1, label: 'Squat 150kg by July 1', sub: 'currently 142kg · 53d left', xp: 800, done: false },
      { id: 2, label: 'Save $5,000 by end of Q2', sub: '$2,550 in vault', xp: 1200, done: false },
      { id: 3, label: 'Ship side-project v1', sub: 'aurora.dev', xp: 1500, done: false },
    ],
  },
  aiQuest: {
    title: 'Read for 25 minutes before opening any feed',
    body: 'The day rewards whoever owns its first hour. Skip the scroll, open your Codex, and lock in a quiet sprint. Sage believes you can do 25 minutes straight.',
  },
};

// ---------- Reducer ----------
function reducer(state, action) {
  switch (action.type) {
    case 'addXP': {
      let xp = state.user.xp + action.amount;
      let level = state.user.level;
      let xpMax = state.user.xpMax;
      while (xp >= xpMax) {
        xp -= xpMax;
        level += 1;
        xpMax = Math.round(xpMax * 1.08);
      }
      return { ...state, user: { ...state.user, xp, level, xpMax } };
    }
    case 'toggleQuest': {
      const list = state.quests[action.group].map((q) =>
        q.id === action.id ? { ...q, done: !q.done } : q
      );
      return { ...state, quests: { ...state.quests, [action.group]: list } };
    }
    case 'toggleLearningTask': {
      const skills = state.learning.skills.map((s) => {
        if (s.id !== action.skillId) return s;
        return {
          ...s,
          tasks: s.tasks.map((t) =>
            t.id === action.taskId ? { ...t, done: !t.done } : t
          ),
        };
      });
      return { ...state, learning: { ...state.learning, skills } };
    }
    default:
      return state;
  }
}

// ---------- Nav config ----------
const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: 'layout-dashboard', accent: '#e7ecf3' },
  { id: 'finances', label: 'Finances', icon: 'wallet', accent: '#34d399' },
  { id: 'fitness', label: 'Fitness', icon: 'dumbbell', accent: '#8b5cf6' },
  { id: 'learning', label: 'Learning Hub', icon: 'book-open', accent: '#f97316' },
  { id: 'arena', label: 'AI Agent Arena', icon: 'sparkles', accent: '#38bdf8' },
];

// ---------- Sidebar ----------
function Sidebar({ view, setView, user, density }) {
  return (
    <aside
      className="shrink-0 flex flex-col border-r hairline"
      style={{
        width: density === 'cozy' ? 232 : 76,
        background: 'rgba(7,9,15,0.55)',
        backdropFilter: 'blur(10px)',
      }}
    >
      {/* Logo */}
      <div className="px-4 pt-5 pb-4 flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #fbbf24, #f97316)', color: '#0a0d14' }}>
          <Icon name="mountain" size={18} strokeWidth={2.25} />
        </div>
        {density === 'cozy' ? (
          <div>
            <div className="text-[14px] font-bold display tracking-tight">Ascend</div>
            <div className="text-[10px] num uppercase tracking-[0.18em]" style={{ color: 'var(--text-2)' }}>Personal Dev OS</div>
          </div>
        ) : null}
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 pt-4 space-y-1">
        {density === 'cozy' && (
          <div className="text-[10px] num uppercase tracking-[0.2em] px-2 mb-2" style={{ color: 'var(--text-2)' }}>Realms</div>
        )}
        {NAV.map((item) => {
          const active = view === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={`nav-item w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[13px] font-medium ${active ? 'active' : ''}`}
              style={{
                color: active ? 'var(--text-0)' : 'var(--text-1)',
                '--nav-accent': item.accent,
                justifyContent: density === 'compact' ? 'center' : 'flex-start',
              }}
              title={item.label}
            >
              <Icon name={item.icon} size={16} style={{ color: active ? item.accent : 'inherit' }} />
              {density === 'cozy' && <span>{item.label}</span>}
              {density === 'cozy' && active ? (
                <span className="ml-auto text-[10px] num px-1.5 py-0.5 rounded-md" style={{ background: `${item.accent}1f`, color: item.accent }}>•</span>
              ) : null}
            </button>
          );
        })}
      </nav>

      {/* Footer — avatar with level */}
      <div className="px-3 pb-4 mt-4 space-y-3">
        {density === 'cozy' ? (
          <div className="rounded-2xl p-3 hairline border flex items-center gap-3" style={{ background: 'rgba(255,255,255,0.02)' }}>
            <div className="relative">
              <div className="w-10 h-10 rounded-xl overflow-hidden" style={{ background: 'linear-gradient(135deg, #312e81, #6d28d9)' }}>
                <div className="w-full h-full flex items-center justify-center text-[14px] font-semibold display" style={{ color: '#e9d5ff' }}>LO</div>
              </div>
              <div className="absolute -bottom-1 -right-1">
                <div className="lvl-chip text-[9px] px-1.5 py-0.5 rounded-md" style={{ boxShadow: '0 0 10px rgba(251,191,36,0.5)' }}>LVL {user.level}</div>
              </div>
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[12.5px] font-semibold truncate">{user.name}</div>
              <div className="text-[10.5px] num truncate" style={{ color: 'var(--text-2)' }}>{user.handle} · Ascendant</div>
            </div>
            <button className="text-[var(--text-2)] hover:text-[var(--text-0)] transition-colors p-1" title="Settings">
              <Icon name="settings" size={14} />
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl overflow-hidden" style={{ background: 'linear-gradient(135deg, #312e81, #6d28d9)' }}>
                <div className="w-full h-full flex items-center justify-center text-[13px] font-semibold" style={{ color: '#e9d5ff' }}>LO</div>
              </div>
              <div className="absolute -bottom-1 -right-1 lvl-chip text-[9px] px-1.5 py-0.5 rounded-md">{user.level}</div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}

// ---------- Header ----------
function Header({ user, view, density, onSearch }) {
  const navItem = NAV.find((n) => n.id === view) || NAV[0];
  const xpPct = user.xp / user.xpMax;
  return (
    <header className="px-5 sm:px-7 pt-5 pb-4 border-b hairline sticky top-0 z-30" style={{ background: 'rgba(7,9,15,0.7)', backdropFilter: 'blur(14px)' }}>
      <div className="flex items-center gap-4">
        {/* breadcrumb */}
        <div className="hidden sm:flex items-center gap-2 min-w-0">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${navItem.accent}1f`, color: navItem.accent }}>
            <Icon name={navItem.icon} size={15} />
          </div>
          <div className="min-w-0">
            <div className="text-[10px] num uppercase tracking-[0.18em]" style={{ color: 'var(--text-2)' }}>Realm</div>
            <div className="text-[14px] font-semibold display truncate">{navItem.label}</div>
          </div>
        </div>

        {/* XP Bar */}
        <div className="flex-1 max-w-[560px] mx-auto">
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-2">
              <LevelBadge level={user.level} size={28} />
              <span className="text-[11px] num uppercase tracking-[0.18em]" style={{ color: 'var(--text-2)' }}>Ascendant</span>
            </div>
            <div className="text-[11px] num" style={{ color: 'var(--text-1)' }}>
              <span style={{ color: 'var(--text-0)' }}>{user.xp.toLocaleString()}</span> / {user.xpMax.toLocaleString()} XP · <span style={{ color: '#fbbf24' }}>{(user.xpMax - user.xp).toLocaleString()} to LVL {user.level+1}</span>
            </div>
          </div>
          <XPBar value={user.xp} max={user.xpMax} height={8} animated />
        </div>

        {/* Right cluster */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* search */}
          <div className="hidden md:flex items-center gap-2 px-3 py-2 rounded-xl" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid var(--line)' }}>
            <Icon name="search" size={13} style={{ color: 'var(--text-2)' }} />
            <input
              type="text"
              placeholder="Search quests, skills…"
              className="bg-transparent outline-none text-[12px] w-44"
              style={{ color: 'var(--text-0)' }}
            />
            <span className="num text-[10px] px-1 py-0.5 rounded" style={{ color: 'var(--text-2)', background: 'rgba(255,255,255,0.04)' }}>⌘K</span>
          </div>

          {/* Streak */}
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl" style={{
            background: 'linear-gradient(180deg, rgba(249,115,22,0.12), rgba(249,115,22,0.04))',
            border: '1px solid rgba(249,115,22,0.25)',
          }}>
            <Icon name="flame" size={15} className="flame" style={{ color: '#f97316' }} />
            <div className="leading-none">
              <div className="num text-[14px] font-bold" style={{ color: '#fb923c' }}>{user.streak}</div>
              <div className="text-[9px] num uppercase tracking-[0.18em]" style={{ color: 'var(--text-2)' }}>day streak</div>
            </div>
          </div>

          {/* Coins */}
          <div className="hidden lg:flex items-center gap-2 px-3 py-2 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid var(--line)' }}>
            <div className="w-4 h-4 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #fbbf24, #f97316)', color: '#0a0d14' }}>
              <span className="text-[8px] font-bold">⊕</span>
            </div>
            <div className="num text-[12.5px] font-semibold">2,140</div>
          </div>

          {/* Notif */}
          <button className="relative w-9 h-9 rounded-xl flex items-center justify-center transition-colors hover:bg-white/[0.06]" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid var(--line)' }}>
            <Icon name="bell" size={15} />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full" style={{ background: '#f97316', boxShadow: '0 0 8px #f97316' }} />
          </button>
        </div>
      </div>
    </header>
  );
}

// ---------- Tweaks ----------
function TweaksUI({ tweaks, setTweak }) {
  return (
    <window.TweaksPanel title="Tweaks">
      <TweakSection label="Theme">
        <TweakColor
          tweakKey="accentFinance"
          label="Finance accent"
          value={tweaks.accentFinance}
          onChange={(v)=>setTweak('accentFinance', v)}
          options={['#34d399','#10b981','#22d3ee','#a3e635']}
        />
        <TweakColor
          tweakKey="accentFitness"
          label="Fitness accent"
          value={tweaks.accentFitness}
          onChange={(v)=>setTweak('accentFitness', v)}
          options={['#8b5cf6','#38bdf8','#ec4899','#a78bfa']}
        />
        <TweakColor
          tweakKey="accentLearning"
          label="Learning accent"
          value={tweaks.accentLearning}
          onChange={(v)=>setTweak('accentLearning', v)}
          options={['#f97316','#fbbf24','#f43f5e','#facc15']}
        />
      </TweakSection>
      <TweakSection label="Layout">
        <TweakRadio
          tweakKey="density"
          label="Sidebar"
          value={tweaks.density}
          onChange={(v)=>setTweak('density', v)}
          options={[{value:'cozy',label:'Cozy'},{value:'compact',label:'Icons'}]}
        />
        <TweakToggle
          tweakKey="auroraBg"
          label="Aurora background"
          value={tweaks.auroraBg}
          onChange={(v)=>setTweak('auroraBg', v)}
        />
      </TweakSection>
      <TweakSection label="Gameplay">
        <TweakButton
          tweakKey="grantXP"
          label="Grant 100 XP"
          onClick={()=>window.__grantXP && window.__grantXP(100)}
        >
          +100 XP
        </TweakButton>
        <TweakButton
          tweakKey="resetQuests"
          label="Reset quests"
          onClick={()=>window.__resetQuests && window.__resetQuests()}
        >
          Reset
        </TweakButton>
      </TweakSection>
    </window.TweaksPanel>
  );
}

// ---------- App ----------
function App() {
  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "accentFinance": "#34d399",
    "accentFitness": "#8b5cf6",
    "accentLearning": "#f97316",
    "density": "cozy",
    "auroraBg": true
  }/*EDITMODE-END*/;

  const [tweaks, setTweak] = window.useTweaks(TWEAK_DEFAULTS);
  const [view, setView] = useS('dashboard');
  const [state, dispatch] = useReducer(reducer, INITIAL_STATE);
  const { show: showToast, Toast } = useToast();

  // expose for Tweaks panel buttons
  useE(() => {
    window.__grantXP = (n) => {
      dispatch({ type: 'addXP', amount: n });
      showToast({ title: `+${n} XP`, sub: 'Granted by the gods', icon: 'sparkles', color: '#fbbf24' });
    };
    window.__resetQuests = () => {
      // Reload to reset state
      window.location.reload();
    };
  }, []);

  // Inject accents
  useE(() => {
    const r = document.documentElement;
    r.style.setProperty('--finance', tweaks.accentFinance);
    r.style.setProperty('--fitness', tweaks.accentFitness);
    r.style.setProperty('--learning', tweaks.accentLearning);
  }, [tweaks.accentFinance, tweaks.accentFitness, tweaks.accentLearning]);

  const ViewComponent = {
    dashboard: DashboardView,
    finances: FinancesView,
    fitness: FitnessView,
    learning: LearningView,
    arena: ArenaView,
  }[view];

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar view={view} setView={setView} user={state.user} density={tweaks.density} />
      <main className="flex-1 flex flex-col overflow-hidden" data-screen-label={`Ascend · ${NAV.find(n=>n.id===view).label}`}>
        <Header user={state.user} view={view} density={tweaks.density} />
        <div className="flex-1 overflow-y-auto px-5 sm:px-7 py-6">
          <ViewComponent state={state} dispatch={dispatch} toast={showToast} />
        </div>
      </main>
      <Toast />
      <TweaksUI tweaks={tweaks} setTweak={setTweak} />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
